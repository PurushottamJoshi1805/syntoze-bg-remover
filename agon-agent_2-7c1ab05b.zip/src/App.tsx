import { ChangeEvent, DragEvent, useEffect, useRef, useState } from 'react'
import { ArrowDownToLine, ArrowRight, BadgeCheck, Check, ChevronDown, CircleHelp, CloudUpload, Copy, CreditCard, Image as ImageIcon, LoaderCircle, LockKeyhole, Menu, MousePointer2, RefreshCw, ShieldCheck, Sparkles, Trash2, WandSparkles, X } from 'lucide-react'
import './App.css'

type CashfreeWindow = Window & { Cashfree?: (options: { mode: 'sandbox' | 'production' }) => { checkout: (options: { paymentSessionId: string; redirectTarget: string }) => Promise<unknown> } }
type WorkState = 'idle' | 'paying' | 'removing' | 'ready'

const MAX_FILE_BYTES = 3 * 1024 * 1024

function App() {
  const inputRef = useRef<HTMLInputElement>(null)
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState('')
  const [result, setResult] = useState('')
  const [phone, setPhone] = useState('')
  const [orderId, setOrderId] = useState('')
  const [state, setState] = useState<WorkState>('idle')
  const [notice, setNotice] = useState('')
  const [dragging, setDragging] = useState(false)
  const [copied, setCopied] = useState(false)
  const [cashfreeReady, setCashfreeReady] = useState(() => Boolean((window as CashfreeWindow).Cashfree))
  const [mobileMenu, setMobileMenu] = useState(false)

  useEffect(() => {
    if ((window as CashfreeWindow).Cashfree) {
      return
    }
    const script = document.createElement('script')
    script.src = 'https://sdk.cashfree.com/js/v3/cashfree.js'
    script.async = true
    script.onload = () => setCashfreeReady(true)
    script.onerror = () => setNotice('Could not load Cashfree checkout. Please check your connection and try again.')
    document.head.appendChild(script)
    return () => { script.onload = null }
  }, [])

  useEffect(() => () => {
    if (preview) URL.revokeObjectURL(preview)
    if (result) URL.revokeObjectURL(result)
  }, [preview, result])

  const chooseFile = (next: File | undefined) => {
    if (!next) return
    setNotice('')
    if (!next.type.startsWith('image/')) {
      setNotice('Choose a JPG, PNG, or WEBP image to get started.')
      return
    }
    if (next.size > MAX_FILE_BYTES) {
      setNotice('This image is larger than 3 MB. Choose a smaller image to continue.')
      return
    }
    if (preview) URL.revokeObjectURL(preview)
    if (result) URL.revokeObjectURL(result)
    setFile(next)
    setPreview(URL.createObjectURL(next))
    setResult('')
    setOrderId('')
    setState('idle')
  }

  const onInput = (event: ChangeEvent<HTMLInputElement>) => chooseFile(event.target.files?.[0])
  const onDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault()
    setDragging(false)
    chooseFile(event.dataTransfer.files?.[0])
  }

  const removeBackground = async (currentOrder: string) => {
    if (!file) return
    setState('removing')
    setNotice('Your payment is confirmed. Making your image transparent…')
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader()
        reader.onload = () => typeof reader.result === 'string' ? resolve(reader.result) : reject(new Error('Unable to read this image.'))
        reader.onerror = () => reject(new Error('Unable to read this image.'))
        reader.readAsDataURL(file)
      })
      const response = await fetch('/api/remove-background', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_id: currentOrder, image: dataUrl, filename: file.name }),
      })
      const payload = await response.json()
      if (!response.ok) throw new Error(payload.error || 'Could not remove the background. Please try again.')
      const binary = atob(payload.image)
      const bytes = new Uint8Array(binary.length)
      for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i)
      const output = URL.createObjectURL(new Blob([bytes], { type: 'image/png' }))
      setResult(output)
      setState('ready')
      setNotice('All done. Your transparent PNG is ready to take home.')
    } catch (error) {
      setState('idle')
      setNotice(error instanceof Error ? error.message : 'Something went wrong. Please try again.')
    }
  }

  const startCheckout = async () => {
    const cleanPhone = phone.replace(/\D/g, '').slice(-10)
    if (!file) {
      setNotice('Upload an image first, then you can continue to payment.')
      return
    }
    if (cleanPhone.length !== 10) {
      setNotice('Enter a valid 10-digit mobile number for your Cashfree receipt.')
      return
    }
    if (!cashfreeReady || !(window as CashfreeWindow).Cashfree) {
      setNotice('Cashfree checkout is still loading. Please try again in a moment.')
      return
    }
    setNotice(orderId ? 'Checking your previous payment…' : 'Creating your secure ₹1 checkout…')
    setState('paying')
    try {
      if (orderId) {
        const previousCheck = await fetch('/api/verify-payment', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ order_id: orderId }),
        })
        const previousStatus = await previousCheck.json()
        if (previousCheck.ok && previousStatus.paid) {
          await removeBackground(orderId)
          return
        }
      }
      setNotice('Creating your secure ₹1 checkout…')
      const create = await fetch('/api/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customer_phone: cleanPhone }),
      })
      const order = await create.json()
      if (!create.ok) throw new Error(order.error || 'Could not start checkout. Please try again.')
      setOrderId(order.order_id)
      const cashfree = (window as CashfreeWindow).Cashfree!({ mode: order.mode })
      await cashfree.checkout({ paymentSessionId: order.payment_session_id, redirectTarget: '_modal' })

      // Never trust the checkout UI's callback: only the server's Cashfree order lookup unlocks the result.
      for (let attempt = 0; attempt < 18; attempt += 1) {
        const verify = await fetch('/api/verify-payment', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ order_id: order.order_id }),
        })
        const status = await verify.json()
        if (verify.ok && status.paid) {
          await removeBackground(order.order_id)
          return
        }
        if (status.status === 'FAILED' || status.status === 'CANCELLED') break
        await new Promise(resolve => window.setTimeout(resolve, 1500))
      }
      setState('idle')
      setNotice('Payment is not confirmed yet. If you completed it, wait a moment and try again.')
    } catch (error) {
      setState('idle')
      setNotice(error instanceof Error ? error.message : 'Checkout was interrupted. You can try again.')
    }
  }

  const copyImage = async () => {
    if (!result || state !== 'ready') return
    try {
      const blob = await (await fetch(result)).blob()
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })])
      setCopied(true)
      window.setTimeout(() => setCopied(false), 2000)
    } catch {
      setNotice('Image copying is not supported by this browser. Use Download PNG instead.')
    }
  }

  const reset = () => {
    if (preview) URL.revokeObjectURL(preview)
    if (result) URL.revokeObjectURL(result)
    setFile(null)
    setPreview('')
    setResult('')
    setOrderId('')
    setPhone('')
    setNotice('')
    setState('idle')
    if (inputRef.current) inputRef.current.value = ''
  }

  const busy = state === 'paying' || state === 'removing'

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#home" aria-label="Syntoze home">
          <span className="brand-mark"><WandSparkles size={19} strokeWidth={2.2} /></span>
          <span>syntoze<span className="brand-period">.</span></span>
        </a>
        <nav className={`top-links ${mobileMenu ? 'is-open' : ''}`} aria-label="Main navigation">
          <a className="nav-active" href="#workspace" onClick={() => setMobileMenu(false)}>Background remover</a>
          <a href="#how-it-works" onClick={() => setMobileMenu(false)}>How it works</a>
          <a href="#faq" onClick={() => setMobileMenu(false)}>FAQ</a>
        </nav>
        <div className="top-right">
          <span className="secure-label"><ShieldCheck size={15} /> Secure & private</span>
          <button className="mobile-toggle" onClick={() => setMobileMenu(value => !value)} aria-label="Toggle navigation">{mobileMenu ? <X size={20} /> : <Menu size={20} />}</button>
        </div>
      </header>

      <main id="home">
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-dot" /> THE QUICK, CLEAN CUTOUT</div>
            <h1>Goodbye background.<br /><span>Hello, <em>anything.</em></span></h1>
            <p>One photo in. A perfectly transparent PNG out. No subscription, no fuss — just <strong>₹1 per image.</strong></p>
            <div className="hero-proof"><span><Check size={14} /> Clean transparent PNG</span><i /> <span><Check size={14} /> Pay only when you need it</span></div>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" />
            <div className="art-card art-card-back"><div className="art-sun" /><div className="art-plant"><span /><span /><span /><b /></div><div className="art-ground" /></div>
            <div className="art-card art-card-front"><div className="checker"><div className="art-vase"><span className="vase-neck" /><span className="vase-body" /><span className="vase-shadow" /></div></div><div className="art-label"><span><Sparkles size={13} /></span> BG removed</div></div>
            <div className="art-spark spark-a">✳</div><div className="art-spark spark-b">✦</div>
          </div>
        </section>

        <section className="workspace-section" id="workspace">
          <div className="workspace-heading">
            <div><div className="section-kicker">YOUR CREATIVE SPACE</div><h2>Make the background disappear.</h2></div>
            <div className="price-pill"><span className="price-spark"><Sparkles size={14} /></span><span>Just <strong>₹1</strong> per image</span></div>
          </div>

          <div className={`workbench ${file ? 'has-image' : ''}`}>
            <div className="workbench-top"><div className="workbench-title"><span className="live-dot" /> <span>Untitled project</span></div><span className="workbench-meta">PNG export <span>·</span> Full resolution</span></div>
            <div className="workbench-body">
              <div className="canvas-column">
                <div className={`image-stage ${file ? 'stage-filled' : ''}`} onDragOver={event => { event.preventDefault(); setDragging(true) }} onDragLeave={() => setDragging(false)} onDrop={onDrop}>
                  {!file ? (
                    <div className={`upload-prompt ${dragging ? 'is-dragging' : ''}`}>
                      <div className="upload-icon-wrap"><CloudUpload size={27} strokeWidth={1.8} /></div>
                      <h3>Drop your image here</h3>
                      <p>or browse files from your device</p>
                      <button className="browse-button" onClick={() => inputRef.current?.click()}><ImageIcon size={16} /> Choose an image <ArrowRight size={15} /></button>
                      <span className="file-note">JPG, PNG or WEBP <b>·</b> Up to 3 MB</span>
                    </div>
                  ) : (
                    <div className="preview-pair">
                      <div className="preview-card">
                        <div className="preview-image image-original"><img src={preview} alt="Original image preview" /></div>
                        <span className="preview-tag">ORIGINAL</span>
                      </div>
                      <div className="preview-arrow"><ArrowRight size={17} /></div>
                      <div className={`preview-card ${state === 'ready' ? '' : 'locked-card'}`}>
                        <div className="preview-image checkerboard">
                          {state === 'ready' && result ? <img src={result} alt="Background removed image preview" /> : <div className="locked-preview"><div className="lock-bubble"><LockKeyhole size={20} /></div><span>{state === 'removing' ? 'Making magic…' : 'Your cutout goes here'}</span></div>}
                        </div>
                        <span className={`preview-tag ${state === 'ready' ? 'tag-ready' : ''}`}>{state === 'ready' ? 'TRANSPARENT PNG' : 'PREVIEW LOCKED'}</span>
                      </div>
                    </div>
                  )}
                  <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp" onChange={onInput} hidden />
                </div>
                {file && <div className="file-row"><div className="file-type-icon"><ImageIcon size={17} /></div><div className="file-info"><strong>{file.name}</strong><span>{(file.size / 1024).toFixed(0)} KB <i>·</i> Ready to process</span></div><button className="icon-button remove-file" aria-label="Remove image" onClick={reset}><Trash2 size={17} /></button></div>}
              </div>

              <aside className="checkout-panel">
                <div className="panel-overline">YOUR IMAGE, REIMAGINED</div>
                <h3>{state === 'ready' ? 'Your cutout is ready.' : 'Ready for a fresh start?'}</h3>
                <p className="panel-description">{state === 'ready' ? 'Background gone. Your transparent PNG is ready to download or copy.' : 'Our AI takes care of the fiddly bits — hair, edges, all of it.'}</p>
                <div className="included-list"><div><span className="list-check"><Check size={12} /></span><span>High-resolution PNG</span></div><div><span className="list-check"><Check size={12} /></span><span>Transparent background</span></div><div><span className="list-check"><Check size={12} /></span><span>Pay once, use forever</span></div></div>

                {state === 'ready' ? (
                  <div className="result-actions"><a className="primary-action" href={result} download={`${file?.name.replace(/\.[^.]+$/, '') || 'synt-oze-cutout'}.png`}><ArrowDownToLine size={17} /> Download PNG</a><button className="secondary-action" onClick={copyImage}><Copy size={16} /> {copied ? 'Copied!' : 'Copy image'}</button><button className="new-image-action" onClick={reset}><RefreshCw size={14} /> Remove another background</button></div>
                ) : (
                  <div className="payment-area">
                    <label className="phone-label" htmlFor="phone">Mobile number <span>for your Cashfree receipt</span></label>
                    <div className="phone-input"><span className="india-code">+91</span><span className="phone-divider" /><input id="phone" value={phone} onChange={event => setPhone(event.target.value.replace(/\D/g, '').slice(0, 10))} placeholder="10-digit mobile number" inputMode="numeric" autoComplete="tel-national" /></div>
                    <button className="primary-action pay-button" disabled={!file || busy || !cashfreeReady} onClick={startCheckout}>
                      {busy ? <><LoaderCircle className="spin" size={17} /> {state === 'paying' ? 'Opening secure checkout…' : 'Removing background…'}</> : <><LockKeyhole size={16} /> Pay ₹1 & unlock <ArrowRight size={16} /></>}
                    </button>
                    <div className="payment-note"><span><LockKeyhole size={12} /> Secure checkout by</span><strong>cashfree</strong><b>·</b><span>UPI, cards & more</span></div>
                  </div>
                )}
                {notice && <div className={`status-message ${state === 'ready' ? 'status-success' : ''}`} role="status"><span>{state === 'ready' ? <BadgeCheck size={15} /> : <CircleHelp size={15} />}</span>{notice}</div>}
                <div className="payment-terms"><LockKeyhole size={12} /> No charge until you approve payment. Output unlocks after confirmation.</div>
              </aside>
            </div>
            <div className="workbench-foot"><span><MousePointer2 size={13} /> {file ? 'Looks good? Your original stays private.' : 'Your images are processed securely and never stored.'}</span><button onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}>How it works <ArrowRight size={13} /></button></div>
          </div>
        </section>

        <section className="steps-section" id="how-it-works">
          <div className="steps-header"><div className="section-kicker">THREE STEPS. ZERO BACKGROUND.</div><h2>Simple as <em>one, two, done.</em></h2><p>Professional-looking cutouts without the professional-sized price tag.</p></div>
          <div className="steps-grid"><article className="step-card"><div className="step-number">01</div><div className="step-icon icon-lilac"><CloudUpload size={21} /></div><h3>Drop it in</h3><p>Choose any JPG, PNG or WEBP from your device. Your original stays yours.</p><span className="step-connector"><ArrowRight size={15} /></span></article><article className="step-card"><div className="step-number">02</div><div className="step-icon icon-peach"><CreditCard size={20} /></div><h3>Pay one rupee</h3><p>Complete a secure Cashfree checkout. No subscriptions, ever.</p><span className="step-connector"><ArrowRight size={15} /></span></article><article className="step-card"><div className="step-number">03</div><div className="step-icon icon-mint"><Sparkles size={20} /></div><h3>Take it anywhere</h3><p>Download or copy your high-quality, transparent PNG.</p></article></div>
        </section>

        <section className="faq-section" id="faq"><div><div className="section-kicker">A FEW GOOD QUESTIONS</div><h2>Good to know.</h2></div><div className="faq-list"><details><summary>When can I download my image? <ChevronDown size={17} /></summary><p>Only after Cashfree confirms your ₹1 payment. The download and copy buttons appear once payment is verified and your cutout is finished.</p></details><details><summary>What happens to my photo? <ChevronDown size={17} /></summary><p>Your photo is sent securely to our image-processing provider only after payment is confirmed. Syntoze doesn't keep a copy of your image or finished cutout.</p></details><details><summary>Which image formats are supported? <ChevronDown size={17} /></summary><p>Upload JPG, PNG, or WEBP images up to 3 MB. Your finished cutout is delivered as a transparent PNG.</p></details><details><summary>What payment methods can I use? <ChevronDown size={17} /></summary><p>Cashfree checkout supports the payment methods enabled for your Cashfree account, including UPI, cards, and more.</p></details></div></section>
      </main>
      <footer className="footer"><a className="brand footer-brand" href="#home"><span className="brand-mark"><WandSparkles size={16} /></span><span>syntoze<span className="brand-period">.</span></span></a><span>Little edits. Big difference.</span><span className="footer-right">Made for the image you have in mind <Sparkles size={13} /></span></footer>
    </div>
  )
}

export default App
