type RequestLike = { method?: string; body?: Record<string, unknown>; headers?: Record<string, string | string[] | undefined> }
type ResponseLike = { status: (code: number) => ResponseLike; json: (data: unknown) => void }

export default async function handler(req: RequestLike, res: ResponseLike) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' })
  const appId = process.env.CASHFREE_APP_ID
  const secret = process.env.CASHFREE_SECRET_KEY
  if (!appId || !secret) return res.status(503).json({ error: 'Cashfree is not configured yet. Add CASHFREE_APP_ID and CASHFREE_SECRET_KEY in Vercel.' })

  const phone = String(req.body?.customer_phone ?? '').replace(/\D/g, '').slice(-10)
  if (!/^\d{10}$/.test(phone)) return res.status(400).json({ error: 'Enter a valid 10-digit mobile number.' })

  const mode = process.env.CASHFREE_ENV?.toUpperCase() === 'PRODUCTION' ? 'production' : 'sandbox'
  const baseUrl = mode === 'production' ? 'https://api.cashfree.com/pg' : 'https://sandbox.cashfree.com/pg'
  const orderId = `syntoze_${Date.now()}_${crypto.randomUUID().slice(0, 8)}`
  try {
    const response = await fetch(`${baseUrl}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-version': '2026-01-01', 'x-client-id': appId, 'x-client-secret': secret },
      body: JSON.stringify({
        order_id: orderId,
        order_amount: 1,
        order_currency: 'INR',
        customer_details: { customer_id: `customer_${phone}`, customer_phone: phone },
        order_meta: { return_url: `${getOrigin(req)}/?payment=complete&order_id=${orderId}` },
        order_note: 'Syntoze background removal — one image',
      }),
    })
    const result = await response.json()
    if (!response.ok || !result.payment_session_id) {
      console.error('Cashfree order creation failed:', response.status, result)
      return res.status(502).json({ error: 'Cashfree could not create your payment. Please try again.' })
    }
    return res.status(200).json({ order_id: result.order_id, payment_session_id: result.payment_session_id, mode })
  } catch (error) {
    console.error('Cashfree request error:', error)
    return res.status(502).json({ error: 'Could not connect to Cashfree. Please try again.' })
  }
}

function getOrigin(req: RequestLike) {
  const headers = req.headers ?? {}
  const host = headers['x-forwarded-host'] ?? headers.host ?? ''
  const proto = headers['x-forwarded-proto'] ?? 'https'
  return `${proto}://${host}`
}
