type RequestLike = { method?: string; body?: Record<string, unknown> }
type ResponseLike = { status: (code: number) => ResponseLike; json: (data: unknown) => void }

export default async function handler(req: RequestLike, res: ResponseLike) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' })
  const appId = process.env.CASHFREE_APP_ID
  const secret = process.env.CASHFREE_SECRET_KEY
  if (!appId || !secret) return res.status(503).json({ error: 'Cashfree payment verification is not configured.' })
  const orderId = String(req.body?.order_id ?? '')
  if (!/^syntoze_[a-zA-Z0-9_-]{10,80}$/.test(orderId)) return res.status(400).json({ error: 'Invalid order.' })
  const mode = process.env.CASHFREE_ENV?.toUpperCase() === 'PRODUCTION' ? 'production' : 'sandbox'
  const baseUrl = mode === 'production' ? 'https://api.cashfree.com/pg' : 'https://sandbox.cashfree.com/pg'

  try {
    const response = await fetch(`${baseUrl}/orders/${encodeURIComponent(orderId)}/payments`, {
      headers: { 'x-api-version': '2026-01-01', 'x-client-id': appId, 'x-client-secret': secret },
    })
    if (!response.ok) {
      console.error('Cashfree verification failed:', response.status, await response.text())
      return res.status(502).json({ error: 'Could not verify payment with Cashfree.' })
    }
    const payments = await response.json()
    const successful = Array.isArray(payments) && payments.some((payment: { payment_status?: string }) => payment.payment_status === 'SUCCESS')
    const status = Array.isArray(payments) ? payments[0]?.payment_status ?? 'PENDING' : 'PENDING'
    return res.status(200).json({ paid: successful, status: successful ? 'SUCCESS' : status })
  } catch (error) {
    console.error('Cashfree verification request failed:', error)
    return res.status(502).json({ error: 'Could not verify payment. Please try again.' })
  }
}
