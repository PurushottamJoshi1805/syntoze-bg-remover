type RequestLike = { method?: string; body?: Record<string, unknown> }
type ResponseLike = { status: (code: number) => ResponseLike; json: (data: unknown) => void }

export default async function handler(req: RequestLike, res: ResponseLike) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' })
  const appId = process.env.CASHFREE_APP_ID
  const secret = process.env.CASHFREE_SECRET_KEY
  const removeBgKey = process.env.REMOVE_BG_API_KEY
  if (!appId || !secret) return res.status(503).json({ error: 'Cashfree payment verification is not configured.' })
  if (!removeBgKey) return res.status(503).json({ error: 'Image processing is not configured yet. Add REMOVE_BG_API_KEY in Vercel.' })

  const orderId = String(req.body?.order_id ?? '')
  const imageData = String(req.body?.image ?? '')
  const filename = String(req.body?.filename ?? 'image.png').replace(/[^\w.()-]/g, '_').slice(0, 100)
  if (!/^syntoze_[a-zA-Z0-9_-]{10,80}$/.test(orderId)) return res.status(400).json({ error: 'Invalid payment order.' })
  const match = imageData.match(/^data:image\/(png|jpeg|webp);base64,([a-zA-Z0-9+/=]+)$/)
  if (!match) return res.status(400).json({ error: 'Upload a valid JPG, PNG, or WEBP image.' })
  const bytes = Buffer.from(match[2], 'base64')
  if (bytes.length > 3 * 1024 * 1024) return res.status(413).json({ error: 'Image exceeds the 3 MB upload limit.' })

  const mode = process.env.CASHFREE_ENV?.toUpperCase() === 'PRODUCTION' ? 'production' : 'sandbox'
  const baseUrl = mode === 'production' ? 'https://api.cashfree.com/pg' : 'https://sandbox.cashfree.com/pg'
  try {
    const paymentCheck = await fetch(`${baseUrl}/orders/${encodeURIComponent(orderId)}/payments`, {
      headers: { 'x-api-version': '2026-01-01', 'x-client-id': appId, 'x-client-secret': secret },
    })
    if (!paymentCheck.ok) return res.status(502).json({ error: 'Could not verify payment. Your image is still locked.' })
    const payments = await paymentCheck.json()
    if (!Array.isArray(payments) || !payments.some((payment: { payment_status?: string }) => payment.payment_status === 'SUCCESS')) {
      return res.status(402).json({ error: 'Payment has not cleared. Your image is still locked.' })
    }

    const form = new FormData()
    form.append('image_file', new Blob([bytes], { type: `image/${match[1]}` }), filename)
    form.append('size', 'auto')
    form.append('format', 'png')
    const processed = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST', headers: { 'X-Api-Key': removeBgKey }, body: form,
    })
    if (!processed.ok) {
      const detail = await processed.text()
      console.error('remove.bg request failed:', processed.status, detail)
      return res.status(502).json({ error: processed.status === 402 ? 'Image processing credits are unavailable. Please contact support.' : 'Image processing failed. Please try again.' })
    }
    const output = Buffer.from(await processed.arrayBuffer())
    return res.status(200).json({ image: output.toString('base64') })
  } catch (error) {
    console.error('Image processing request failed:', error)
    return res.status(502).json({ error: 'Could not process the image right now. Please try again.' })
  }
}
