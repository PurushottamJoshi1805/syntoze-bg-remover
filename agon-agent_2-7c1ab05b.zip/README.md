# Syntoze background remover

A Vite + React app with Vercel serverless endpoints for Cashfree checkout and paid-only background removal.

## Vercel environment variables

Add these in **Vercel → Project → Settings → Environment Variables**, then redeploy:

| Variable | Required | Description |
| --- | --- | --- |
| `CASHFREE_APP_ID` | Yes | Cashfree PG app/client ID |
| `CASHFREE_SECRET_KEY` | Yes | Cashfree PG secret key; keep server-side only |
| `CASHFREE_ENV` | No | `SANDBOX` by default; set to `PRODUCTION` for live checkout |
| `REMOVE_BG_API_KEY` | Yes | remove.bg API key for transparent-image processing |

Cashfree creates a fixed INR 1 order. The server checks Cashfree's payment status before both allowing image processing and returning any cutout. The browser doesn't unlock download/copy controls until this confirmation and image processing complete. For test payments, use Cashfree sandbox keys and `CASHFREE_ENV=SANDBOX`.

Uploaded images are limited to 3 MB to fit serverless request limits. Processing uses remove.bg; provider account credits and image limits apply.
